import {
  View,
  Text,
  ScrollView,
  Image,
  Pressable,
} from "react-native";
import React, { useEffect, useState } from "react";
import tailwind from "twrnc";
import AntDesign from "@expo/vector-icons/AntDesign";
import { LinearGradient } from "expo-linear-gradient";
import { fetchMixtapeCovers, fetchPixabaySongs } from "@/src/constants/services/API";
import { Song } from "@/src/constants/services/Models";
import ArtistCard from "@/src/components/ArtistCard";

const Index = () => {
  const [songs, setSongs] = useState<Song[]>([]);
  const [albums, setAlbums] = useState<Song[]>([]);

  useEffect(() => {
    const loadSongs = async () => {
      const fetchedSongs = await fetchPixabaySongs();
      setSongs(fetchedSongs);
      const fetchAlbums = await fetchMixtapeCovers();
      setAlbums(fetchAlbums);
    };

    loadSongs();
  }, []);

  const greetingMessage = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 16) return "Good Afternoon";
    return "Good Evening";
  };

  const greeting = greetingMessage();

  const renderItem = ({ item }: { item: Song }) => {
    return (
      <Pressable
        style={tailwind`flex-row items-center gap-[10px] flex-1 my-[10px] mx-[4px] bg-[#202020] rounded-[4px] z-3`}
      >
        <Image style={{ height: 55, width: 55 }} source={{ uri: item.image }} />
        <View style={tailwind`flex-1 justify-center`}>
          <Text style={tailwind`text-white text-[13px] font-bold ml-2`}>
            {item.title.length > 10
              ? `${item.title.slice(0, 10)}...`
              : item.title}
          </Text>
        </View>
      </Pressable>
    );
  };

  return (
    <ScrollView contentContainerStyle={tailwind`pt-4 px-2 bg-[#101010] pb-28`}>
      {/* Header */}
      <View style={tailwind`p-[6px] flex-row items-center justify-between`}>
        <View style={tailwind`flex-row items-center`}>
          <Image
            source={{ uri: "https://randomuser.me/api/portraits/women/75.jpg" }}
            style={tailwind`w-[40px] h-[40px] rounded-full object-cover`}
            resizeMode="cover"
          />
          <Text style={tailwind`ml-[13px] text-[20px] font-bold text-white`}>
            {greeting}
          </Text>
        </View>
        <AntDesign name="user" size={24} color="white" />
      </View>

      {/* Category Buttons */}
      <View style={tailwind`mt-4 flex-row items-center`}>
        <Pressable style={tailwind`bg-[#282828] p-[12px] rounded-full mb-4`}>
          <Text style={tailwind`text-white text-[15px]`}>Music</Text>
        </Pressable>
        <Pressable
          style={tailwind`bg-[#282828] ml-[15px] p-[12px] rounded-full mb-4`}
        >
          <Text style={tailwind`text-white text-[15px]`}>
            Podcast & Shows
          </Text>
        </Pressable>
      </View>

      {/* Liked Songs and Hiphops */}
      <View style={tailwind`flex-row items-center justify-between`}>
        <Pressable
          style={tailwind`flex-row items-center gap-[10px] flex-1 my-[10px] mx-[4px] bg-[#202020] rounded-[4px] z-3`}
        >
          <LinearGradient
            colors={["#33006f", "#FFFFFF"]}
            style={tailwind`w-[55px] h-[55px] items-center justify-center rounded-[4px]`}
          >
            <AntDesign name="heart" size={24} color="white" />
          </LinearGradient>
          <Text style={tailwind`text-white text-[13px] font-bold ml-2`}>
            Liked Songs
          </Text>
        </Pressable>

        <View
          style={tailwind`flex-row items-center gap-[10px] flex-1 my-[10px] mx-[4px] bg-[#202020] rounded-[4px] z-3`}
        >
          <Image
            style={tailwind`w-[55px] h-[55px]`}
            source={{ uri: "https://randomuser.me/api/portraits/women/75.jpg" }}
          />
          <View>
            <Text style={tailwind`text-white text-[13px] font-bold ml-2`}>
              Hiphops
            </Text>
          </View>
        </View>
      </View>

      {/* First 4 Songs Grid */}
      <View style={tailwind`flex-row flex-wrap justify-between`}>
        {songs.slice(0, 4).map((item, index) => (
          <View key={index} style={tailwind`w-[48%]`}>
            {renderItem({ item })}
          </View>
        ))}
      </View>

      {/* Top Artists */}
      <Text style={tailwind`text-white font-bold text-[19px] mt-6`}>
        Your Top Artists
      </Text>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={tailwind`mt-2`}
      >
        {songs.map((item, index) => (
          <View key={index} style={tailwind`mr-4`}>
            <ArtistCard item={item} />
          </View>
        ))}
      </ScrollView>



      <Text style={tailwind`text-white font-bold text-[19px] mt-6`}>
        Your Top Albums
      </Text>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={tailwind`mt-[10px]`}
      >
        {albums.map((item, index) => (
          <View key={index} style={tailwind`mr-4`}>
            <ArtistCard item={item} />
          </View>
        ))}
      </ScrollView>
    </ScrollView>
  );
};

export default Index;
