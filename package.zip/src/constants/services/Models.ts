export type Song = {
  id: string
  title: string
  artist: string
  image: string
  audioUrl: string
}
