import { Song } from "./Models";
import uuid from 'react-native-uuid';


export const fetchPixabaySongs = async (): Promise<Song[]> => {
  const mockSongs: Song[] = [
    {
      id:uuid.v4(),
      title: 'Midnight Jazz',
      artist: 'Noir Ensemble',
      image: 'https://d1csarkz8obe9u.cloudfront.net/posterpreviews/jazz-dark-album-cover-template-966020e215ba3c34a2b5d68b2d386cd7.jpg',
      audioUrl: 'https://example.com/audio/midnight-jazz.mp3'
    },
    {
      id: uuid.v4(),
      title: 'Trap Shadows',
      artist: 'Dark Beat',
      image: 'https://d1csarkz8obe9u.cloudfront.net/posterpreviews/black-best-cover-album-music-art-trap-mixtap-design-template-ae996baa5e07382c91133d053b965970.webp',
      audioUrl: 'https://example.com/audio/trap-shadows.mp3'
    },
    {
      id: uuid.v4(),
      title: 'Masked Frequencies',
      artist: 'Echo Phantom',
      image: 'https://d1csarkz8obe9u.cloudfront.net/posterpreviews/yellow-masked-album-cover-design-template-b30329fef5a81ae46e0b52f947dc0a4d.webp',
      audioUrl: 'https://example.com/audio/masked-frequencies.mp3'
    },
    {
      id: uuid.v4(),
      title: 'Static Rise',
      artist: 'Lo Vibe',
      image: 'https://d1csarkz8obe9u.cloudfront.net/posterpreviews/mixtape-cover-album-cover-design-template-4029e33bd677639637777c9f983a4414.webp',
      audioUrl: 'https://example.com/audio/static-rise.mp3'
    },
    {
      id: uuid.v4(),
      title: 'Darkwave Dreams',
      artist: 'Black Circuit',
      image: 'https://d1csarkz8obe9u.cloudfront.net/posterpreviews/black-cd-mixtape-album-cover-artwork-templat-design-template-d164f42b73fdee2bfe901f1aba184de3.webp?ts=1729177345',
      audioUrl: 'https://example.com/audio/darkwave-dreams.mp3'
    },
    {
      id: uuid.v4(),
      title: 'Neon Pulse',
      artist: 'CD Runner',
      image: 'https://d1csarkz8obe9u.cloudfront.net/posterpreviews/cd-mixtape-album-cover-artwork-template-design-723467b9241ae90c505b419816a148d6.webp?ts=1747794750',
      audioUrl: 'https://example.com/audio/neon-pulse.mp3'
    },
    {
      id: uuid.v4(),
      title: 'Torn Beats',
      artist: 'Grunge Mode',
      image: 'https://d1csarkz8obe9u.cloudfront.net/posterpreviews/grunge-portrait-album-with-static-and-torn-te-design-template-e01c60c528f5899a4e945500d18ac1ce.webp?ts=1750753007',
      audioUrl: 'https://example.com/audio/torn-beats.mp3'
    },
     {
      id: uuid.v4(),
      title: 'Static Rise',
      artist: 'Lo Vibe',
      image: 'https://d1csarkz8obe9u.cloudfront.net/posterpreviews/mixtape-cover-album-cover-design-template-4029e33bd677639637777c9f983a4414.webp',
      audioUrl: 'https://example.com/audio/static-rise.mp3'
    },
  ]

  return new Promise((resolve) => {
    setTimeout(() => resolve(mockSongs), 500) // simulate slight network delay
  })
}

// src/constants/services/fetchMixtapeCovers.ts


// src/constants/services/fetchMixtapeCovers.ts



export const fetchMixtapeCovers = async (): Promise<Song[]> => {
  return [
    {
      id: uuid.v4(),
      title: "Green Beat",
      artist: "DJ Emerald",
      image:
        "https://d1csarkz8obe9u.cloudfront.net/posterpreviews/green-music-cd-cover-design-template-e013b657d602b6d7f63edd0d05f66d28.webp?ts=1737201122",
      audioUrl: "https://www.example.com/audio/green-beat.mp3",
    },
    {
      id: uuid.v4(),
      title: "Trap Vibes",
      artist: "Trap Soul",
      image:
        "https://d1csarkz8obe9u.cloudfront.net/posterpreviews/brown-best-cover-album-music-art-trap-mixtap-design-template-5a0dd02eef46eb28e996ec98d5d99ffa.webp?ts=1737315015",
      audioUrl: "https://www.example.com/audio/trap-vibes.mp3",
    },
    {
      id: uuid.v4(),
      title: "Fresh Mix",
      artist: "Mix Master",
      image:
        "https://d1csarkz8obe9u.cloudfront.net/posterpreviews/green-mixtape-album-cover-design-template-5eeefb633133c2e5d42fd09144fe1a53.webp?ts=1745872386",
      audioUrl: "https://www.example.com/audio/fresh-mix.mp3",
    },
    {
      id: uuid.v4(),
      title: "Classic Drop",
      artist: "Old Skool",
      image:
        "https://d1csarkz8obe9u.cloudfront.net/posterpreviews/cd-mixtape-album-cover-artwork-template-design-c0f7d509e8211190cc7472c4cce672e4.webp?ts=1741975340",
      audioUrl: "https://www.example.com/audio/classic-drop.mp3",
    },
    {
      id: uuid.v4(),
      title: "White Flame",
      artist: "Lil Ice",
      image:
        "https://d1csarkz8obe9u.cloudfront.net/posterpreviews/white-mixtape-cover-album-cover-design-template-6dc5500c4f6586e15f773376ffcdc3b4.webp?ts=1750366186",
      audioUrl: "https://www.example.com/audio/white-flame.mp3",
    },
    {
      id: uuid.v4(),
      title: "CD Banger",
      artist: "DJ Compact",
      image:
        "https://d1csarkz8obe9u.cloudfront.net/posterpreviews/cd-mixtape-album-cover-artwork-template-design-723467b9241ae90c505b419816a148d6.webp?ts=1747794750",
      audioUrl: "https://www.example.com/audio/cd-banger.mp3",
    },
    {
      id: uuid.v4(),
      title: "Rap Heat",
      artist: "MC Blaze",
      image:
        "https://d1csarkz8obe9u.cloudfront.net/posterpreviews/best-cover-album-music-art-trap-mixtape-rap-design-template-72d3b1df3669d777edc82c7113d1c651.webp?ts=1737576145",
      audioUrl: "https://www.example.com/audio/rap-heat.mp3",
    },
  ];
};


