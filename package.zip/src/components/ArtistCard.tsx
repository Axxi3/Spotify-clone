import { Image, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { Song } from '@/src/constants/services/Models'
import tailwind from 'twrnc'

type Props = {
  item: Song
}

const ArtistCard = ({ item }: Props) => {
  return (
    <View style={tailwind`ml-[7px] mt-[3px]`}>
      <Image source={{ uri: item.image }} style={tailwind`w-[130px] h-[130px]`} />
      <Text style={tailwind`text-white text-[13px] font-bold mt-2`} numberOfLines={1} ellipsizeMode="tail">
        {item.title.length > 18 ? item.title.slice(0, 18) + '...' : item.title}
      </Text>
    </View>
  )
}

export default ArtistCard

